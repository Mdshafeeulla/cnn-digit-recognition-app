import streamlit as st
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import transforms
from PIL import Image
import numpy as np

# --- 1. Streamlit App Layout (MOVE THIS UP) ---
st.set_page_config(page_title="MNIST Digit Predictor", page_icon="🔢")

# --- 2. Defining the Convolutional Network Class ---
class ConvolutionalNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 6, 3, 1)
        self.conv2 = nn.Conv2d(6, 16, 3, 1)
        self.fc1 = nn.Linear(5*5*16, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84,10)

    def forward(self, X):
        X = F.relu(self.conv1(X))
        X = F.max_pool2d(X, 2, 2)
        X = F.relu(self.conv2(X))
        X = F.max_pool2d(X, 2, 2)
        X = X.view(-1, 5*5*16)
        X = F.relu(self.fc1(X))
        X = F.relu(self.fc2(X))
        X = self.fc3(X)
        return F.log_softmax(X, dim=1)

# --- 3. Loading the Pre-trained Model  ---
@st.cache_resource # Caching the model loading to prevent re-loading on every rerun
def load_model():
    model = ConvolutionalNetwork()
    try:
        model.load_state_dict(torch.load('Number_Predictor.pt'))
        model.eval() # Setting the model to evaluation mode
        return model
    except FileNotFoundError:
        st.error("Model file 'Number_Predictor.pt' not found. Please run your training script first to save the model.")
        st.stop() 
    except Exception as e:
        st.error(f"Error loading model: {e}")
        st.stop()

model = load_model()

# --- 4. Defining Image Transformations for Prediction ---
prediction_transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=1), 
    transforms.Resize((28, 28)),                 
    transforms.ToTensor(),                       
])

# --- 5. Streamlit App Content ---
st.title("🔢 MNIST Digit Predictor")
st.markdown("Upload a grayscale image of a handwritten digit (0-9) and let the model predict it!")

uploaded_file = st.file_uploader("Choose an image...", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Image', use_container_width=True)
    st.write("")
    st.write("Classifying...")

    # Preprocess the image
    transformed_image = prediction_transform(image)
    
    # Add a batch dimension
    input_tensor = transformed_image.unsqueeze(0)

    # Perform prediction
    with torch.no_grad():
        output = model(input_tensor)
        probabilities = F.softmax(output, dim=1)
        predicted_class = torch.argmax(probabilities, dim=1).item()
        confidence = probabilities[0, predicted_class].item() * 100

    st.success(f"Prediction: This looks like a **{predicted_class}**!")
    st.info(f"Confidence: {confidence:.2f}%")

st.markdown("""
---
*Note: This model was trained on the MNIST dataset, which consists of grayscale handwritten digits. For best results, ensure your uploaded image is a clear, single digit in grayscale.*
""")